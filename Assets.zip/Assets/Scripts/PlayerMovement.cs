
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayerMovement: MonoBehaviour
{

    private Animator animator;
    public float fallThreshold = -10f;
    private float _speed = 0;
    private Rigidbody _rb;
    private float jumpForce = 200;
    private int maxjumps = 2;
    public int jumps = 0;
     public ParticleSystem jumpParticles; // Reference to the jump particle system
   
 

    void Start(){


        _rb = GetComponent<Rigidbody>();
         animator = GetComponent<Animator>();

    }

    

    void Update(){

       


        if(Input.GetKey(KeyCode.LeftShift)){

            _speed = 6f;

        }
        else{
            _speed = 4f;
        }



         
        var vel = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")) * _speed;
        vel.y = _rb.velocity.y;
        _rb.velocity = vel;

        

   
        
        


        if(Input.GetKeyDown(KeyCode.Space) && jumps < maxjumps){

          
        _rb.AddForce(Vector3.up * jumpForce);
            
            jumpParticles.Play();
            jumps++;
            
            
        }
        




        if (transform.position.y < fallThreshold)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name); // Reload the current scene
        }





    }

void OnCollisionEnter(Collision coll){

    if(coll.gameObject.CompareTag("Plane"))
    {
        jumps = 0;
    }

    

}

}
