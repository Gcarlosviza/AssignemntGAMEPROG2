using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Powerup : MonoBehaviour
{
    public float hoverSpeed = 0.1f; // Speed of hovering
    public float rotationSpeed = 50.0f; // Speed of rotation
    public float hoverAmplitude = 0.1f; // Amplitude of hovering
    private Vector3 startPosition;

    public int scoreValue = 50; // Points to add to the score when the player scores
    private ScoreManager scoreManager; // Reference to the score manager script
    // Start is called before the first frame update
    void Start()
    {
         startPosition = transform.position;
         scoreManager = FindObjectOfType<ScoreManager>(); // Find the ScoreManager script in the scene
    }
    

    // Update is called once per frame
    void Update()
    {
        Vector3 position = startPosition;
        position.y += Mathf.Sin(Time.time * hoverSpeed) * hoverAmplitude;
        transform.position = position;

        // Rotate the power-up
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            scoreManager.score += scoreValue; // Add points to the score
            scoreManager.UpdateScore(); // Update the score display
         
            Destroy(gameObject); // Destroy the power-up game object
        }
    }
}
