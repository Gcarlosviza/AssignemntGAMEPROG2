using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ScoreManager : MonoBehaviour
{
    public int score;
    public Text scoreText; 
    
    public void Start()
    {
        score = PlayerPrefs.GetInt("score");
        scoreText.text = "Score: ";
    }

    public void UpdateScore()
    {
       
        scoreText.text = "Score: " + score;
        PlayerPrefs.SetInt("score", score);

        
        
    }
    



}

