using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public static class PlayerPrefsManager
{
  
    public static int score
    {
        get { return PlayerPrefs.GetInt("score", 0); }
        set { PlayerPrefs.SetInt("score", value); }
    }

   

 
}
