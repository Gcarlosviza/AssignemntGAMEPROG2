using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
       public Transform player; // Reference to the player object
    public float smoothTime = 0.3f; // Smooth time for camera movement

    private Vector3 velocity = Vector3.zero; // Velocity for smooth damping

    private void FixedUpdate()
    {
        // Calculate the target position for the camera based on the player's position
        Vector3 targetPosition = player.position;
        targetPosition.z = transform.position.z; // Keep camera's z position constant

        // Smoothly move the camera towards the target position using damping
        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
    }
}
