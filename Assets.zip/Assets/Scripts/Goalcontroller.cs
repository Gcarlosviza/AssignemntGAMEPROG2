using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Goalcontroller : MonoBehaviour
{
   
    private ScoreManager scoreManager; 

    public int finalPoints;

    void SaveFinalPoints()
    {
        PlayerPrefs.SetInt("score", finalPoints);
    }

      void OnTriggerEnter(Collider other)
    {

        
        if (other.gameObject.CompareTag("Player"))
        {
           
           
            Destroy(other.gameObject); 
            


            GameManager.GetInstance();

            if (SceneManager.GetActiveScene().name == "SampleScene")
            {   
                SaveFinalPoints();
                SceneManager.LoadScene("level 2");
 
                
             

            }
            if (SceneManager.GetActiveScene().name == "level 2")
            {
                SaveFinalPoints();
                SceneManager.LoadScene("level 3");
            }
             if (SceneManager.GetActiveScene().name == "level 3")
            {
                SaveFinalPoints();
                SceneManager.LoadScene("End");
            }

            
        }
       
          
    }
    
}
