using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpPowerUp : MonoBehaviour
{

    public GameObject jump;

    public float hoverSpeed = 1f; // Speed of hovering
    public float rotationSpeed = 1f; // Speed of rotation
    public float hoverAmplitude = 0.5f; // Amplitude of hovering

    private Vector3 initialPosition; // Starting position of power-up
    private Quaternion initialRotation; 
    private PlayerMovement player;


    private float respawnTime = 10.0f; // Change this value to adjust the respawn time






    // Start is called before the first frame update
    void Start()
    {
         initialPosition = transform.position;
         initialRotation = transform.rotation;

        player = GameObject.FindObjectOfType<PlayerMovement>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (jump == null)
        {
        StartCoroutine(RespawnPowerUp());
        }

         Vector3 position = initialPosition;
        position.y += Mathf.Sin(Time.time * hoverSpeed) * hoverAmplitude;
        transform.position = position;

        // Rotate the power-up
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
    }


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            player.jumps = 0;

            Destroy(gameObject); // Destroy the power-up game object
            StartCoroutine(RespawnPowerUp());
        }
    }



    IEnumerator RespawnPowerUp()
    {
        yield return new WaitForSeconds(respawnTime);
        Instantiate(jump, initialPosition, initialRotation);
    }
}
