using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class EndManager : MonoBehaviour
{
    int finalPoints;
    public Text finalPointsText;
    private ScoreManager scoreManager;
    void Start()
    {
        finalPoints = PlayerPrefs.GetInt("score");
        finalPointsText.text = "Final Points: " + finalPoints;
        
    }
    void update(){
        
        
    }


}
